
% Construct generator polynomial for (n,k) cyclic code
% Taking user input for the code length and message length
clc;
n=input("Enter the code length:");
k=input("Enter message length:");
% ConstructingGenerator Polynomial
pol = cyclpoly(n,k);
gp = poly2sym(pol);
disp("Generator Polynomial:");
disp(gp);
