% Implement BASK modulation and demodulation technique

clc;

% BASK Modulation 

n=input('Enter binary input s/g b(t)');
[M N]=size(n);

% Unipolar mapping
for i=1:N
    if n(i)==0
        um(i)=0;
    else
        um(i)=1;
    end
end

%unipolar NRZ signal

s=100;%samples per bit
i=1; %index of input bits
t=0:1/s:N;%time

for j=1:length(t)
    if t(j)<=i
        b(j)=um(i);
    else
        b(j)=um(i);
    i=i+1;
    end
end

subplot(411);
plot(t,b,'b');
xlabel('t');
ylabel('b(t)');
title('input binary sequence');

% Carrier wave
c=sin(2*pi*t);
subplot(412);
plot(t,c,'m');
xlabel('t');
ylabel('Asin(w0t)');
title('Carrier wave');

% BASK modulated wave
x=b.*c;
subplot(413);
plot(t,x,'k');
xlabel('t');
ylabel('Vbask');
title('BASK modulated output wave');

% Demodulation of BASK

y=x;
% Product o/p
y1=y.*c;
%subplot(414);
%plot(t,y1,'k');
%xlabel('t');
%ylabel('amplitude');
%title('product modulator output');
 %integrator
int_op=[];
for i=0:s:length(y1)-s
    int_o=(1/s)*trapz(y1(i+1:i+s));
    int_op=[int_op int_o];
end

threshold=0.5;
disp('detected bits:');
detected_bits=(round(int_op,1)>=threshold);
disp(detected_bits);

