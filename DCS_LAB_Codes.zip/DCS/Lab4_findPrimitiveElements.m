% Find the primitive elements from the given set under mod-n
clc;
n=input("Enter the value n");
disp(n);
A=0:n-1;
fprintf("Element of set under mod-n");
disp(A);
fprintf("The primitive elements from the given set under mod-n");
e=A(isPrimitiveRoot(A,n));
disp(e);
