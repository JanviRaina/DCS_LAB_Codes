% Construct generator matrix for Generator Polynomial in Systematic Form
clc;
clear;
%taking n,k as input
n=input("enter code word length:");
k=input("enter message bit length:");
poly=cyclpoly(n,k);
gpoly=poly2sym(poly);
disp("polynomial of cyclic code");
disp(gpoly);
[parity,gene]=cyclgen(n,poly,'nonsys');
disp("Generator matrix for given cyclic code in non systematic form");
disp(gene);
Ge=mod(rref(gene),2);
disp("Generator matrix for given cyclic code in systematic form");
disp(Ge);
