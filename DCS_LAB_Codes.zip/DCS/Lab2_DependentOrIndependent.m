% Check whether given set of n-tuple vectors are linearly dependent or independent

clc;
clear;
n=input("enter the length of vectors where we have to check:");

if(n==2) 
x=input("enter the first vector:");
y=input("enter the second vector:");
%x=[1,1,1,0];
%y=[1,1,1,0];
    sum1=y;
    sum2=x;
    sum3=x+y;
    if((sum(sum1)==0) || (sum(sum2)==0) || (sum(rem(sum3,2))==0))
        disp("given sets of vectors are dependent.")
    else   
        disp("given sets of vectors are independent.")
    end

elseif n==3
x=input("enter the first vector:");
y=input("enter the second vector:");
z=input("enter the third vector");
    sum1=z;
    sum2=y;
    sum3=y+z;
    sum4=x;
    sum5=x+z;
    sum6=x+y;
    sum7=x+y+z;
    if((sum(sum1)==0) || (sum(sum2)==0) || (sum(rem(sum3,2))==0) || (sum(sum4)==0) || (sum(rem(sum5,2))==0) || (sum(rem(sum6,2))==0) || (sum(rem(sum7,2))==0))
        disp("given sets of vectors are dependent.");
    else   
        disp("given sets of vectors are independent.");
    end 
    
elseif n==4
x=input("enter the first vector:");
y=input("enter the second vector:");
z=input("enter the third vector");
w=input("enter the fourth vector");
%   x=[1,0,0,1];
%   y=[1,0,1,1];
%   z=[1,1,0,0];
%   w=[1,0,0,1];
    sum1=w;
    sum2=z;
    sum3=z+w;
    sum4=y;
    sum5=y+w;
    sum6=y+z;
    sum7=y+z+w;
    sum8=x;
    sum9=x+w;
    sum10=x+z;
    sum11=x+z+w;
    sum12=x+y;
    sum13=x+y+w;
    sum14=x+y+z;
    sum15=x+y+z+w;
    
    if( (sum(sum1)==0) || (sum(sum2)==0) || (sum(rem(sum3,2))==0) || (sum(sum4)==0) || (sum(rem(sum5,2))==0) || (sum(rem(sum6,2))==0) || (sum(rem(sum7,2))==0) ...
            || (sum(sum8)==0) || (sum(rem(sum9,2))==0) || (sum(rem(sum10,2))==0) || (sum(rem(sum11,2))==0) || (sum(rem(sum12,2))==0) || (sum(rem(sum13,2))==0) ...
            || (sum(rem(sum14,2))==0) || (sum(rem(sum15,2))==0) )
        disp("given sets of vectors are dependent.");
    else   
        disp("given sets of vectors are independent.");
    end 
end
 
% v1=[1,0,0,1,0,1,0,0,1,1,1,0]
% v2=[1,0,1,1,1,0,0,0,1,0,1,0]
% v3=[1,1,0,0,0,1,0,1,0,1,1,0]
% v4=[1,0,0,1,0,0,0,1,0,0,0,1]
