% Implementation of (n,k) Hamming Code encoder/decoder

clc;
n=input('Enter value of n');
k=input('Enter value of k:');

% [1 0 1 1]
m=input('Enter message bits matrix');

% Parity matrix [1 1 0;1 1 1;1 0 1;1 1 1]
P=input('Enter parity matrix');
g=[eye(k,k) P];
disp('The generator matrix is');
disp(g);

% Encoding :
c=rem(m*g,2);
disp("The codeword is");
disp(c);

% Decoding :
% [1 1 1 1 1 0 0]
recieved_codeword=input('Enter the received code');
h=[P.',eye(n-k)];
ht=h.';
%disp("Parity Check Matrix is");
%disp(ht);
syndrome = mod(recieved_codeword*ht,2);

% flaging position of the error in codeword and correcting it
flag = 0;
for iter= 1:n
    if ~flag
        errvect = zeros(1,n);
        errvect(iter) = 1;
        search = mod(errvect*ht,2);
        if search == syndrome
            flag = 1;
            error_position=iter;
        end
    end
end

if(flag==1)
    disp('The error is at position')
    disp(error_position);     
else
    disp("The recieved codeword is correct.")
end
  
recieved_codeword(error_position)=~recieved_codeword(error_position);
disp("Corrected recieved codeword is");
disp(recieved_codeword);