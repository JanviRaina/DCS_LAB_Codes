% Implement BPSK modulation and demodulation technique
clc;
% BPSK modulation
inp=input('Enter binary input s/g b(t)');
[M N]=size(inp);
inp_bit=[];
nb=100; % bbit/bit
for i=1:1:N   
   if inp(i)==1
      inp_val=ones(1,nb);
   else
       inp_val=zeros(1,nb);
   end
   inp_bit=[inp_bit inp_val];
end
% bit period
Tb=0.0001; 
t1=Tb/nb:Tb/nb:nb*N*(Tb/nb);
f1 = figure(1);
set(f1,'color',[1 1 1]);
subplot(3,1,1);
plot(t1,inp_bit);
grid on;
axis([ 0 Tb*N -0.5 1.5]);
ylabel('b(t)');
xlabel('t(sec)');
title('Binary Sequence');
% BPSK Modulation
Ac=4;  % Amplitude of carrier signal
m=4;  % fc>>fs fc=m*fs fs=1/Tb
fc=m*(1/Tb); % carrier frequency for bit 1
fi1=0;  % Phase for bit 1
fi2=pi; % Phase change for bit 0
t2=Tb/nb:Tb/nb:Tb;                
t2L=length(t2);
modulatedX=[];
for (i=1:1:N)
   if (inp(i)==1)
       modulatedX0=Ac*sin(2*pi*fc*t2+fi1);%modulation signal with carrier signal 1
   else
       modulatedX0=Ac*sin(2*pi*fc*t2+fi2);%modulation signal with carrier signal 2
   end
   modulatedX=[modulatedX modulatedX0];
end
t3=Tb/nb:Tb/nb:Tb*N;
subplot(3,1,2);
plot(t3,modulatedX);
xlabel('t(sec)');
ylabel('Vbpsk');
title('BPSK modulation ');
% x=modulatedX,Considering h=1; % Fading , w=0; % Noise , y=h.*x+w;
% BPSK Demodulation
y=modulatedX;
y_dem=[];
for n=t2L:t2L:length(y)
 t=Tb/nb:Tb/nb:Tb;
 c=sin(2*pi*fc*t); % carrier siignal
 y_dem0=c.*y((n-(t2L-1)):n);
 t4=Tb/nb:Tb/nb:Tb;
 z=trapz(t4,y_dem0); % intregation
 A_dem=round((2*z/Tb));                                    
 if(A_dem>Ac/2) % logic level = Ac/2
   A=1;
 else
   A=0;
 end
 y_dem=[y_dem A];
end
y_out=y_dem;
xinp_bit=[];
for n=1:length(y_out);
   if y_out(n)==1;
      xinp_val=ones(1,nb);
   else y_out(n)==0;
       xinp_val=zeros(1,nb);
   end
    xinp_bit=[xinp_bit xinp_val];
end
t4=Tb/nb:Tb/nb:nb*length(y_out)*(Tb/nb);
subplot(3,1,3)
plot(t4,xinp_bit,'LineWidth',2);grid on;
axis([ 0 Tb*length(y_out) -0.5 1.5]);
ylabel('b(t)');
xlabel(' t(sec)');
title('BPSK demodulation');

