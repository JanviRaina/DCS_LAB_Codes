% Implement BFSK modulation and demodulation technique

clc;
inpx=input('Enter binary sequence')
[M N]=size(inpx);
x_bit=[];
nb=100; % bbit/bit
for n=1:1:N  
   if inpx(n)==1; 
      bitx=ones(1,nb);
   else inpx(n)==0;
       bitx=zeros(1,nb);
   end
    x_bit=[x_bit bitx];
end

% Bit Period
Tb=0.0001; 
t1=Tb/nb:Tb/nb:nb*N*(Tb/nb);

f1 = figure(1);
set(f1,'color',[1 1 1]);
subplot(3,1,1);
plot(t1,x_bit,'lineWidth',2);grid on;
axis([ 0 Tb*N -0.5 1.5]);
ylabel('b(t)');
xlabel('t');
title('b(t)');

% BFSK Modulation

Ac=5;  % Amplitude of carrier signal
mc1=16;  % fc>>fs fc=mc*fs fs=1/Tb
mc2=4;
fc1=mc1*(1/Tb); % carrier frequency for bit 1
fc2=mc2*(1/Tb); % carrier frequency for bit 0
t2=Tb/nb:Tb/nb:Tb;                
t2L=length(t2);
modulated_x=[];
for (i=1:1:N)
   if (inpx(i)==1)
       modulated_x0=Ac*sin(2*pi*fc1*t2);%modulation signal with carrier signal 1
   else
       modulated_x0=Ac*sin(2*pi*fc2*t2);%modulation signal with carrier signal 2
   end
   modulated_x=[modulated_x modulated_x0];
end
t3=Tb/nb:Tb/nb:Tb*N;
subplot(3,1,2);
plot(t3,modulated_x);
xlabel('t');
ylabel('Vbfsk');
title('BFSK modulation');

% x=modulated_x; h=1; % Fading w=0; % Noise y=h.*x+w;
y=modulated_x;
y_dem=[];
for n=t2L:t2L:length(y)
 t=Tb/nb:Tb/nb:Tb;
 dem_carrier1=sin(2*pi*fc1*t); % carrier siignal for information 1
 dem_carrier2=sin(2*pi*fc2*t); % carrier siignal for information 0
 y_dem1=dem_carrier1.*y((n-(t2L-1)):n);
 y_dem2=dem_carrier2.*y((n-(t2L-1)):n);
 t4=Tb/nb:Tb/nb:Tb;
 z1=trapz(t4,y_dem1);  % intregation
 z2=trapz(t4,y_dem2);  % intregation
 A_dem1=round(2*z1/Tb);
 A_dem2= round(2*z2/Tb);
 if(A_dem1>Ac/2)      % % logic level = (Ac)/2
   a=1;
 else(A_dem2>Ac/2)
   a=0;
 end
 y_dem=[y_dem a];
end
x_out=y_dem; % output signal;

% Demodulated signal
dem_bit=[];
for n=1:length(x_out);
   if x_out(n)==1;
      dem_bitx=ones(1,nb);
   else x_out(n)==0;
dem_bitx=zeros(1,nb);
end
dem_bit=[dem_bit dem_bitx];
end
t4=Tb/nb:Tb/nb:nb*length(x_out)*(Tb/nb);
subplot(3,1,3)
plot(t4,dem_bit,'LineWidth',2);grid on;
axis([ 0 Tb*length(x_out) -0.5 1.5]);
ylabel('b(t)');
xlabel('t');
title('Signal after BFSK demodualtion');
