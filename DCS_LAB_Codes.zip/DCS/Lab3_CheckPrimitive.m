
% Check given degree n polynomial is primtive or not
% [1 1 1 1 1 1 1 0 1 0 1]

clc;
P=input('Enter coefficient matrix of polynomial');
disp('The Polynomial is :');
gfpretty(P);

if(gfprimck(P)==1)
   disp('given polynomial is primitive');
else
   disp('given polynomial is not primitive ');
end;

% Examples of Primitive Polynomials : 1+x+x^3, 1+x^2+x^3
